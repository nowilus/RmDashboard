require({
    packages: [
      {
        name: 'react_module_bundle',
        location: com_ibm_bpm_coach.getManagedAssetUrl('react_module_bundle.zip', com_ibm_bpm_coach.assetType_WEB)
      }
    ]
  });